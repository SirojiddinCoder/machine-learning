  import { useEffect, useRef, useState } from 'react';
  import * as tf from '@tensorflow/tfjs';
  import * as handpose from '@tensorflow-models/handpose';
  import Webcam from 'react-webcam';
  import './App.css';
  import { drawHand } from './utils';

  // Qo'l pozitsiyalari asosida harflarni aniqlash
  const fingerLookup = {
    'A': 'A',
    'B': 'B',
    'C': 'C',
    'D': 'D',
    'E': 'E',
    'F': 'F',
    'G': 'G',
    'H': 'H',
    'I': 'I',
    'J': 'J',
    'K': 'K',
    'L': 'L',
    'M': 'M',
    'N': 'N',
    'O': 'O',
    'P': 'P',
    'Q': 'Q',
    'R': 'R',
    'S': 'S',
    'T': 'T',
    'U': 'U',
    'V': 'V',
    'W': 'W',
    'X': 'X',
    'Y': 'Y',
    'Z': 'Z',
    'O\'': 'O\'',
    'G\'': 'G\'',
    'Sh': 'Sh',
    'Ch': 'Ch',
    'Ng': 'Ng',
  };

  const App = () => {
    const webcamRef = useRef(null);
    const canvasRef = useRef(null);
    const [isCameraOn, setIsCameraOn] = useState(false);
    const [detectedLetter, setDetectedLetter] = useState('');
    const [text, setText] = useState('');
    

    const runHandpose = async () => {
      const net = await handpose.load();
      setInterval(() => {
        detect(net);
      }, 100);
    };

    const detect = async (net) => {
      if (
        typeof webcamRef.current !== 'undefined' &&
        webcamRef.current !== null &&
        webcamRef.current.video.readyState === 4
      ) {
        const video = webcamRef.current.video;
        const videoWidth = webcamRef.current.video.videoWidth;
        const videoHeight = webcamRef.current.video.videoHeight;

        webcamRef.current.video.width = videoWidth;
        webcamRef.current.video.height = videoHeight; 
        canvasRef.current.width = videoWidth;
        canvasRef.current.height = videoHeight;

        const hand = await net.estimateHands(video);
        if (hand.length > 0) {
          const gesture = getGestureFromHand(hand[0]);
          if (gesture) {
            setDetectedLetter(gesture);
            setText((prevText) => prevText + gesture);
            
          }
        }

        const ctx = canvasRef.current.getContext('2d');
        drawHand(hand, ctx);
      }
    };

    const getGestureFromHand = (hand) => {
      const landmarks = hand.landmarks;

      // Barmoq bo'g'inlarining burchaklarini va masofalarini hisoblash
      const thumb = landmarks[4];
      const indexFinger = landmarks[8];
      const middleFinger = landmarks[12];
      const ringFinger = landmarks[16];
      const pinkyFinger = landmarks[20];

      // Barmoqlarning pozitsiyasi asosida harf aniqlash
      const handGesture = detectHandShape(thumb, indexFinger, middleFinger, ringFinger, pinkyFinger);

      return fingerLookup[handGesture] || '';
    };

    const detectHandShape = (thumb, indexFinger, middleFinger, ringFinger, pinkyFinger) => {
      // Barmoqlar orasidagi masofalar va joylashuvlarni tahlil qilish
      const isThumbFolded = thumb[0] < indexFinger[0]; // Misol uchun "A" harfi
      const isIndexFingerStraight = indexFinger[1] < middleFinger[1]; // Misol uchun "A" harfi

      // "A" harfi: bosh barmoq bukilgan, ko'rsatkich barmoq tik
      if (isThumbFolded && isIndexFingerStraight) return 'A';

      // "B" harfi: barcha barmoqlar tik
      const isAllFingersStraight = indexFinger[1] < middleFinger[1] && middleFinger[1] < ringFinger[1] && ringFinger[1] < pinkyFinger[1];
      if (isAllFingersStraight) return 'B';

      // "C" harfi: dumaloq shakl, barmoqlar biroz bukilgan
      const isThumbOpposed = thumb[0] < indexFinger[0] && pinkyFinger[0] > ringFinger[0];
      if (isThumbOpposed && isAllFingersBent()) return 'C';

      // "D" harfi: faqat ko'rsatkich barmoq tik, boshqa barmoqlar bukilgan
      if (isThumbFolded && isIndexFingerStraight && areOtherFingersBent()) return 'D'; 

      // "E" harfi: barcha barmoqlar bukilgan
      if (isAllFingersBent() && isThumbFolded) return 'E';

      // Qolgan harflarni shu kabi qo'shish mumkin...

      return '';
    };

    const isAllFingersBent = () => {
      // Barcha barmoqlar bukilganligini tekshirish
      return true; // O'lchovlar aniq bo'lishi kerak
    };

    const areOtherFingersBent = () => {
      // Faqat bitta barmoq tik bo'lganda, boshqa barmoqlar bukilganligini tekshirish
      return true; // Qo'lga qarab moslash mumkin
    };

    const handleCameraStart = () => {
      setIsCameraOn(true);
      runHandpose();
    };

    const handleClearText = () => {
      setText('');
    };

    return (
      <div className="App">
        <header className="App-header">
          <h2>Jumaboyeva Pokiza</h2>
          <h3>Web texnologiyalari asosida tasvirlardan obyektlarni aniqlash  <br/>
          Interfeyslarni loyihalash, tadbiq qilish va ishlab chiqish</h3>

          {isCameraOn && (
            <div className="content-container">
              <div className="camera-container">
                <Webcam ref={webcamRef} className="webcam" />
                <canvas ref={canvasRef} className="canvas" />
              </div>
              <div className="letter-box">
                <p>Tanib olingan harf: {detectedLetter}</p>
                <input type="text" value={text} readOnly className="text-output" />
                <button onClick={handleClearText} className="clear-button">
                  Tozalash
                </button>
              </div>
            </div>
          )}
          {!isCameraOn && (
            <button onClick={handleCameraStart} className="start-button">
            Dasturni ishga tushirish
            </button>
          )}
        </header>
      </div>
    );
  };

  export default App;
      